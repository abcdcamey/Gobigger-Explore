action1_obs=\
 [{"border": [1000, 1000], "total_time": 6, "last_time": 0, "leaderboard": {"0": 9.0, "1": 9.0}},
 {"0": {"rectangle": (100, 500, 400, 800), 
 "overlap": {"food": [[220, 600, 2.0], [200, 700, 2.0]],\
             "thorns": [],"spore": [], "clone": [[200, 600, 3.0, "0", "0"]]}, "team_name": "0"}}]

action2_obs=\
 [{"border": [1000, 1000], "total_time": 6, "last_time": 0, "leaderboard": {"0": 9.0, "1": 9.0}},
 {"0": {"rectangle": (100, 500, 400, 800),
 "overlap": {"food": [[220, 600, 2.0], [200, 700, 2.0]],\
             "thorns": [],"spore": [], "clone": [[200, 600, 10.0, "0", "0"], [170, 600, 3.0, "1", "1"]]}, "team_name": "1"}}]


action4_obs=\
 [{"border": [1000, 1000], "total_time": 6, "last_time": 0, "leaderboard": {"0": 9.0, "1": 9.0}},
 {"0": {"rectangle": (100, 500, 400, 800),
 "overlap": {"food": [[220, 600, 2.0], [200, 700, 2.0]],\
             "thorns": [[170, 600, 9]], "spore": [], "clone": [[200, 600, 10.0, "0", "0"]]}, "team_name": "1"}}]


action5_obs=\
 [{"border": [1000, 1000], "total_time": 6, "last_time": 0, "leaderboard": {"0": 9.0, "1": 9.0}},
 {"0": {"rectangle": (100, 500, 400, 800),
 "overlap": {"food": [[220, 600, 2.0], [200, 700, 2.0]],\
             "thorns": [], "spore": [], "clone": [[200, 600, 12.0, "0", "0"],[200, 620, 15.0, "1", "0"],[110, 600, 16.0, "2", "1"]]}, "team_name": "1"}}]


action6_obs=\
 [{"border": [1000, 1000], "total_time": 6, "last_time": 0, "leaderboard": {"0": 9.0, "1": 9.0}},
 {"0": {"rectangle": (100, 500, 400, 800),
 "overlap": {"food": [[220, 600, 2.0], [200, 700, 2.0]],\
             "thorns": [], "spore": [], "clone": [[200, 600, 12.0, "0", "0"],[200, 620, 15.0, "0", "0"],[110, 600, 16.0, "2", "1"]]}, "team_name": "1"}}]
