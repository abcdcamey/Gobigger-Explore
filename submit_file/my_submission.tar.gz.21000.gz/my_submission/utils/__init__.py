from .global_arr import GlobalArrInit, SetValueArr, GetValueArr
from .global_dict import GlobalDictInit, SetValueDict, GetValueDict